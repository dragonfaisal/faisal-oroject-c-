﻿namespace lab3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            checkBox4 = new CheckBox();
            checkBox3 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox1 = new CheckBox();
            textBox1 = new TextBox();
            button5 = new Button();
            panel1 = new Panel();
            radioButton4 = new RadioButton();
            radioButton3 = new RadioButton();
            radioButton2 = new RadioButton();
            label1 = new Label();
            radioButton1 = new RadioButton();
            button1 = new Button();
            panel2 = new Panel();
            radioButton8 = new RadioButton();
            radioButton7 = new RadioButton();
            radioButton6 = new RadioButton();
            radioButton5 = new RadioButton();
            label3 = new Label();
            label2 = new Label();
            button2 = new Button();
            panel3 = new Panel();
            button4 = new Button();
            button3 = new Button();
            label4 = new Label();
            button6 = new Button();
            groupBox1.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ActiveBorder;
            groupBox1.Controls.Add(checkBox4);
            groupBox1.Controls.Add(checkBox3);
            groupBox1.Controls.Add(checkBox2);
            groupBox1.Controls.Add(checkBox1);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(button5);
            groupBox1.Location = new Point(327, 45);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(217, 286);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "اختر ثم احسب";
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.CheckAlign = ContentAlignment.TopRight;
            checkBox4.Location = new Point(158, 141);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(44, 19);
            checkBox4.TabIndex = 9;
            checkBox4.Text = "100";
            checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.CheckAlign = ContentAlignment.TopRight;
            checkBox3.Location = new Point(164, 105);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(38, 19);
            checkBox3.TabIndex = 8;
            checkBox3.Text = "80";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.CheckAlign = ContentAlignment.TopRight;
            checkBox2.Location = new Point(164, 71);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(38, 19);
            checkBox2.TabIndex = 7;
            checkBox2.Text = "60";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.CheckAlign = ContentAlignment.TopRight;
            checkBox1.Location = new Point(164, 39);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(38, 19);
            checkBox1.TabIndex = 5;
            checkBox1.Text = "40";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(6, 216);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 6;
            // 
            // button5
            // 
            button5.Location = new Point(136, 202);
            button5.Name = "button5";
            button5.Size = new Size(75, 23);
            button5.TabIndex = 5;
            button5.Text = "الناتج";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Control;
            panel1.Controls.Add(radioButton4);
            panel1.Controls.Add(radioButton3);
            panel1.Controls.Add(radioButton2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(radioButton1);
            panel1.Location = new Point(159, 45);
            panel1.Name = "panel1";
            panel1.Size = new Size(135, 234);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.BackColor = SystemColors.AppWorkspace;
            radioButton4.CheckAlign = ContentAlignment.MiddleRight;
            radioButton4.Location = new Point(65, 177);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(50, 19);
            radioButton4.TabIndex = 5;
            radioButton4.TabStop = true;
            radioButton4.Text = "اسود";
            radioButton4.UseVisualStyleBackColor = false;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.BackColor = SystemColors.AppWorkspace;
            radioButton3.CheckAlign = ContentAlignment.MiddleRight;
            radioButton3.Location = new Point(64, 131);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(51, 19);
            radioButton3.TabIndex = 4;
            radioButton3.TabStop = true;
            radioButton3.Text = "اخضر";
            radioButton3.UseVisualStyleBackColor = false;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.BackColor = SystemColors.AppWorkspace;
            radioButton2.CheckAlign = ContentAlignment.MiddleRight;
            radioButton2.Location = new Point(65, 87);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(51, 19);
            radioButton2.TabIndex = 3;
            radioButton2.TabStop = true;
            radioButton2.Text = "اصفر";
            radioButton2.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(56, 9);
            label1.Name = "label1";
            label1.Size = new Size(55, 15);
            label1.TabIndex = 2;
            label1.Text = "لون النص";
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.BackColor = SystemColors.AppWorkspace;
            radioButton1.CheckAlign = ContentAlignment.MiddleRight;
            radioButton1.Location = new Point(65, 39);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(47, 19);
            radioButton1.TabIndex = 0;
            radioButton1.TabStop = true;
            radioButton1.Text = "احمر";
            radioButton1.TextAlign = ContentAlignment.MiddleCenter;
            radioButton1.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.Location = new Point(14, 23);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "enabled";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.Control;
            panel2.Controls.Add(radioButton8);
            panel2.Controls.Add(radioButton7);
            panel2.Controls.Add(radioButton6);
            panel2.Controls.Add(radioButton5);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label2);
            panel2.Location = new Point(12, 45);
            panel2.Name = "panel2";
            panel2.Size = new Size(141, 234);
            panel2.TabIndex = 1;
            // 
            // radioButton8
            // 
            radioButton8.AutoSize = true;
            radioButton8.BackColor = SystemColors.AppWorkspace;
            radioButton8.CheckAlign = ContentAlignment.MiddleRight;
            radioButton8.Location = new Point(42, 177);
            radioButton8.Name = "radioButton8";
            radioButton8.Size = new Size(50, 19);
            radioButton8.TabIndex = 7;
            radioButton8.TabStop = true;
            radioButton8.Text = "اسود";
            radioButton8.UseVisualStyleBackColor = false;
            // 
            // radioButton7
            // 
            radioButton7.AutoSize = true;
            radioButton7.BackColor = SystemColors.AppWorkspace;
            radioButton7.CheckAlign = ContentAlignment.MiddleRight;
            radioButton7.Location = new Point(42, 131);
            radioButton7.Name = "radioButton7";
            radioButton7.Size = new Size(51, 19);
            radioButton7.TabIndex = 6;
            radioButton7.TabStop = true;
            radioButton7.Text = "اصفر";
            radioButton7.UseVisualStyleBackColor = false;
            // 
            // radioButton6
            // 
            radioButton6.AutoSize = true;
            radioButton6.BackColor = SystemColors.AppWorkspace;
            radioButton6.CheckAlign = ContentAlignment.MiddleRight;
            radioButton6.Location = new Point(42, 87);
            radioButton6.Name = "radioButton6";
            radioButton6.Size = new Size(51, 19);
            radioButton6.TabIndex = 5;
            radioButton6.TabStop = true;
            radioButton6.Text = "اخضر";
            radioButton6.UseVisualStyleBackColor = false;
            // 
            // radioButton5
            // 
            radioButton5.AutoSize = true;
            radioButton5.BackColor = SystemColors.AppWorkspace;
            radioButton5.CheckAlign = ContentAlignment.MiddleRight;
            radioButton5.Location = new Point(42, 39);
            radioButton5.Name = "radioButton5";
            radioButton5.Size = new Size(47, 19);
            radioButton5.TabIndex = 4;
            radioButton5.TabStop = true;
            radioButton5.Text = "احمر";
            radioButton5.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(93, 210);
            label3.Name = "label3";
            label3.Size = new Size(34, 15);
            label3.TabIndex = 3;
            label3.Text = "النص";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(27, 9);
            label2.Name = "label2";
            label2.Size = new Size(62, 15);
            label2.TabIndex = 3;
            label2.Text = "لون الخلفية";
            // 
            // button2
            // 
            button2.Location = new Point(134, 23);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 2;
            button2.Text = "button2";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click_1;
            // 
            // panel3
            // 
            panel3.Controls.Add(button4);
            panel3.Controls.Add(button3);
            panel3.Controls.Add(button1);
            panel3.Controls.Add(button2);
            panel3.Location = new Point(12, 285);
            panel3.Name = "panel3";
            panel3.Size = new Size(226, 149);
            panel3.TabIndex = 1;
            // 
            // button4
            // 
            button4.Location = new Point(134, 72);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 4;
            button4.Text = "button4";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click_1;
            // 
            // button3
            // 
            button3.Location = new Point(14, 72);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 3;
            button3.Text = "button3";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(269, 9);
            label4.Name = "label4";
            label4.Size = new Size(38, 15);
            label4.TabIndex = 4;
            label4.Text = "label4";
            // 
            // button6
            // 
            button6.BackColor = Color.Chocolate;
            button6.Location = new Point(384, 377);
            button6.Name = "button6";
            button6.Size = new Size(96, 23);
            button6.TabIndex = 10;
            button6.Text = "NEXT-FORM";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDarkDark;
            ClientSize = new Size(556, 450);
            Controls.Add(button6);
            Controls.Add(label4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private Panel panel1;
        private Panel panel2;
        private Label label1;
        private Button button1;
        private Label label2;
        private Button button2;
        private Panel panel3;
        private Label label3;
        private RadioButton radioButton1;
        private Label label4;
        private RadioButton radioButton4;
        private RadioButton radioButton3;
        private RadioButton radioButton2;
        private RadioButton radioButton8;
        private RadioButton radioButton7;
        private RadioButton radioButton6;
        private RadioButton radioButton5;
        private Button button4;
        private Button button3;
        private CheckBox checkBox4;
        private CheckBox checkBox3;
        private CheckBox checkBox2;
        private CheckBox checkBox1;
        private TextBox textBox1;
        private Button button5;
        private Button button6;
    }
}
