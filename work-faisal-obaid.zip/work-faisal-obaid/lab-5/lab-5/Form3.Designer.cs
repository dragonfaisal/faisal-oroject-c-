﻿namespace lab_5
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            //textBox1 = new TextBox();
            //label1 = new Label();
            //pictureBox1 = new PictureBox();
            //button1 = new Button();
            //button2 = new Button();
            //openFileDialog1 = new OpenFileDialog();
            //button3 = new Button();
            //((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            //SuspendLayout();
            //// 
            //// textBox1
            //// 
            //textBox1.Location = new Point(158, 109);
            //textBox1.Name = "textBox1";
            //textBox1.Size = new Size(100, 23);
            //textBox1.TabIndex = 0;
            //textBox1.TextChanged += textBox1_TextChanged;
            //// 
            //// label1
            //// 
            //label1.AutoSize = true;
            //label1.Location = new Point(88, 112);
            //label1.Name = "label1";
            //label1.Size = new Size(52, 15);
            //label1.TabIndex = 1;
            //label1.Text = "path-file";
            //label1.Click += label1_Click;
            //// 
            //// pictureBox1
            //// 
            //pictureBox1.Location = new Point(25, 171);
            //pictureBox1.Name = "pictureBox1";
            //pictureBox1.Size = new Size(314, 134);
            //pictureBox1.TabIndex = 2;
            //pictureBox1.TabStop = false;
            //// 
            //// button1
            //// 
            //button1.Location = new Point(25, 339);
            //button1.Name = "button1";
            //button1.Size = new Size(75, 23);
            //button1.TabIndex = 3;
            //button1.Text = "close";
            //button1.UseVisualStyleBackColor = true;
            //button1.Click += button1_Click;
            //// 
            //// button2
            //// 
            //button2.Location = new Point(158, 339);
            //button2.Name = "button2";
            //button2.Size = new Size(75, 23);
            //button2.TabIndex = 4;
            //button2.Text = "open-file";
            //button2.UseVisualStyleBackColor = true;
            //button2.Click += button2_Click;
            //// 
            //// openFileDialog1
            //// 
            //openFileDialog1.FileName = "openFileDialog1";
            //// 
            //// button3
            //// 
            //button3.Location = new Point(148, 389);
            //button3.Name = "button3";
            //button3.Size = new Size(75, 23);
            //button3.TabIndex = 5;
            //button3.Text = "next-form";
            //button3.UseVisualStyleBackColor = true;
            //button3.Click += button3_Click;
            //// 
            //// Form3
            //// 
            //AutoScaleDimensions = new SizeF(7F, 15F);
            //AutoScaleMode = AutoScaleMode.Font;
            //BackColor = Color.CornflowerBlue;
            //ClientSize = new Size(392, 477);
            //Controls.Add(button3);
            //Controls.Add(button2);
            //Controls.Add(button1);
            //Controls.Add(pictureBox1);
            //Controls.Add(label1);
            //Controls.Add(textBox1);
            //Name = "Form3";
            //Text = "Form3";
            //Load += Form3_Load;
            //((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            //ResumeLayout(false);
            //PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Label label1;
        private PictureBox pictureBox1;
        private Button button1;
        private Button button2;
        private OpenFileDialog openFileDialog1;
        private Button button3;
    }
}